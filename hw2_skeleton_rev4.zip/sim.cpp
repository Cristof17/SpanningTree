/******************************************************************************/
/* Tema 2 Protocoale de Comunicatie (Aprilie 2015)                            */
/******************************************************************************/

#include "sim.h"

void init_sim(int argc, char **argv) {
  //TODO
}

void clean_sim() {
  //TODO
}

void trigger_events() {
  //TODO
}

void process_messages() {
  //TODO
}

void update_routing_table() {
  //TODO
}
